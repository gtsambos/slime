# SLiMe

SLiMe is a package for simulating admixed tree sequences with local ancestry information.

SliMe combines two existing tree sequence simulation softwares, *SLiM* and *msprime*. Admixed history is simulated forward-in-time with SLiM, while ancient history of the admixing populations is simulated backwards-in-time with msprime.